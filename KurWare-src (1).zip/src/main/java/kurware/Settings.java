package kurware;

import net.minecraft.client.util.InputUtil;

public class Settings {
    public static boolean enabled = false;
    public static boolean players = true;
    public static boolean mobs = false;
    public static boolean silent = false;
    /** true: kamera oynamaz, rotasyon sadece sunucuya gider (F5'te model hedefe bakar). */
    public static boolean freelook = true;
    /** Modülü oyun içinden aç/kapa yapan tuş (null = atanmamış). */
    public static InputUtil.Key bindKey = null;
    public static int chestSpeed = 15;
    public static int fireworkSpeed = 20;
}
