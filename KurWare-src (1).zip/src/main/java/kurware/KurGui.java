package kurware;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class KurGui extends Screen {
    private static final Style F = Style.EMPTY.withFont(Identifier.of("kurware", "ui"));
    static boolean expanded = false;

    private static final int PX = 16, PY = 16, PW = 200;

    interface Row {
        int h();
        void draw(DrawContext g, int x, int y, int w, int mx, int my);
        default boolean click(int x, int y, int w, int mx, int my, int btn) { return false; }
        default void drag(int x, int w, int mx) {}
    }

    private final List<Row> rows = new ArrayList<>();
    private Row dragging;
    private int dragX, dragW;
    private boolean binding = false;

    public KurGui() {
        super(Text.literal("KurWare"));
        rows.add(check("Players", () -> Settings.players, () -> Settings.players = !Settings.players));
        rows.add(check("Mobs", () -> Settings.mobs, () -> Settings.mobs = !Settings.mobs));
        rows.add(slider("Chestplate Speed", 1, 25, () -> Settings.chestSpeed, v -> Settings.chestSpeed = v));
        rows.add(slider("Firework Speed", 1, 40, () -> Settings.fireworkSpeed, v -> Settings.fireworkSpeed = v));
        rows.add(check("Silent", () -> Settings.silent, () -> Settings.silent = true));
        rows.add(check("Normal", () -> !Settings.silent, () -> Settings.silent = false));
        // En altta: Freelook (açıkken tik, kapalıyken boş)
        rows.add(check("Freelook", () -> Settings.freelook, () -> Settings.freelook = !Settings.freelook));
    }

    static void tx(DrawContext g, String s, int x, int y, int color) {
        g.drawText(MinecraftClient.getInstance().textRenderer, Text.literal(s).setStyle(F), x, y, color, false);
    }

    static int tw(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(Text.literal(s).setStyle(F));
    }

    Row check(String label, BooleanSupplier get, Runnable toggle) {
        return new Row() {
            public int h() { return 16; }

            public void draw(DrawContext g, int x, int y, int w, int mx, int my) {
                boolean on = get.getAsBoolean();
                g.fill(x, y + 3, x + 10, y + 13, -9745496);
                g.fill(x + 1, y + 4, x + 9, y + 12, on ? -7447297 : -15395556);
                if (on) {
                    int[][] pts = {{2, 7}, {3, 8}, {4, 9}, {5, 8}, {6, 7}, {7, 6}, {8, 5}};
                    for (int[] q : pts) {
                        g.fill(x + q[0] - 1, y + q[1] - 2, x + q[0], y + q[1] - 1, -1);
                    }
                }
                tx(g, label, x + 16, y + 4, -1644818);
            }

            public boolean click(int x, int y, int w, int mx, int my, int btn) {
                if (btn == 0 && mx >= x && mx < x + w && my >= y && my < y + 16) {
                    toggle.run();
                    return true;
                }
                return false;
            }
        };
    }

    Row slider(String label, int min, int max, IntSupplier get, IntConsumer set) {
        return new Row() {
            public int h() { return 26; }

            public void draw(DrawContext g, int x, int y, int w, int mx, int my) {
                tx(g, label, x, y + 2, -1644818);
                String v = String.valueOf(get.getAsInt());
                tx(g, v, x + w - tw(v), y + 2, -5018625);
                g.fill(x, y + 15, x + w, y + 19, -15395556);
                int filled = (int) ((get.getAsInt() - min) / (float) (max - min) * w);
                g.fill(x, y + 15, x + filled, y + 19, -7447297);
                g.fill(x + filled - 2, y + 13, x + filled + 2, y + 21, -1);
            }

            public boolean click(int x, int y, int w, int mx, int my, int btn) {
                if (btn == 0 && mx >= x && mx < x + w && my >= y && my < y + 24) {
                    drag(x, w, mx);
                    return true;
                }
                return false;
            }

            public void drag(int x, int w, int mx) {
                float f = Math.max(0f, Math.min(1f, (mx - x) / (float) w));
                set.accept(min + Math.round(f * (max - min)));
            }
        };
    }

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        int px = PX, py = PY;
        g.fill(px, py, px + PW, py + 22, -267251176);
        g.fill(px, py + 21, px + PW, py + 22, -7447297);
        tx(g, "KurWare", px + 8, py + 7, -5018625);
        py += 22;

        boolean en = Settings.enabled;
        g.fill(px, py, px + PW, py + 18, en ? -265412787 : -266659038);
        tx(g, "MaceElytraTarget", px + 8, py + 5, en ? -1 : -5592406);
        if (Settings.bindKey != null) {
            // Atanan tuş, yazının sağ altında küçük görünür
            String kn = "[" + Settings.bindKey.getLocalizedText().getString() + "]";
            MatrixStack m = g.getMatrices();
            m.push();
            m.translate(px + 8 + tw("MaceElytraTarget") + 3, py + 9, 0);
            m.scale(0.7f, 0.7f, 1f);
            tx(g, kn, 0, 0, -5018625);
            m.pop();
        }
        tx(g, expanded ? "-" : "+", px + PW - 14, py + 5, -5592406);
        py += 18;

        if (expanded) {
            int total = 8;
            for (Row r : rows) total += r.h();
            g.fill(px, py, px + PW, py + total, -267382763);
            int y = py + 4;
            for (Row r : rows) {
                r.draw(g, px + 10, y, 180, mouseX, mouseY);
                y += r.h();
            }
            py += total;
        }
        tx(g, "Left: toggle | Right: settings | Mid: bind key", px, py + 4, -7829354);

        if (binding) {
            g.fill(0, 0, width, height, 0xB0000000);
            big(g, "PRESS A KEY", width / 2, height / 2 - 30, 4.0f, -1);
            big(g, "ESC = cancel", width / 2, height / 2 + 20, 1.5f, -5592406);
        }
    }

    private static void big(DrawContext g, String s, int cx, int y, float sc, int color) {
        MatrixStack m = g.getMatrices();
        m.push();
        m.translate(cx - tw(s) * sc / 2f, y, 0);
        m.scale(sc, sc, 1f);
        tx(g, s, 0, 0, color);
        m.pop();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (binding) {
            // Fare yan/orta tuşları da atanabilir; sol/sağ tık yok sayılır
            if (button >= 2) {
                Settings.bindKey = InputUtil.Type.MOUSE.createFromCode(button);
                binding = false;
            }
            return true;
        }
        int mx = (int) mouseX, my = (int) mouseY;
        int hy = 38;
        if (mx >= 16 && mx < 216 && my >= hy && my < hy + 18) {
            if (button == 0) Settings.enabled = !Settings.enabled;
            else if (button == 1) expanded = !expanded;
            else if (button == 2) binding = true;
            return true;
        }
        if (expanded) {
            int y = hy + 18 + 4;
            for (Row r : rows) {
                if (r.click(26, y, 180, mx, my, button)) {
                    if (r.h() == 26) {
                        dragging = r;
                        dragX = 26;
                        dragW = 180;
                    }
                    return true;
                }
                y += r.h();
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(dragX, dragW, (int) mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding) {
            if (key == 256) {            // ESC: yazıyı kapat, menü açık kalsın
                binding = false;
            } else if (key != 344) {     // menü tuşu (Right Shift) atanamaz
                Settings.bindKey = InputUtil.fromKeyCode(key, scan);
                binding = false;
            }
            return true;
        }
        if (key == 344) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldPause() { return false; }
}
