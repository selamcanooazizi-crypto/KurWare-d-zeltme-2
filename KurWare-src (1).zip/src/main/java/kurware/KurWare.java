package kurware;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class KurWare implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kurware.menu", InputUtil.Type.KEYSYM, 344, "category.kurware"));
        ClientTickEvents.START_CLIENT_TICK.register(KurWare::onStartTick);
        ClientTickEvents.END_CLIENT_TICK.register(MaceElytraTarget::restore);
    }

    private static boolean bindWasDown = false;

    private static void checkBind(MinecraftClient mc) {
        InputUtil.Key k = Settings.bindKey;
        if (k == null || mc.player == null) {
            bindWasDown = false;
            return;
        }
        long h = mc.getWindow().getHandle();
        boolean down = k.getCategory() == InputUtil.Type.MOUSE
                ? GLFW.glfwGetMouseButton(h, k.getCode()) == GLFW.GLFW_PRESS
                : InputUtil.isKeyPressed(h, k.getCode());
        if (down && !bindWasDown && mc.currentScreen == null) {
            Settings.enabled = !Settings.enabled;
            mc.player.sendMessage(Text.literal("MaceElytraTarget: " + (Settings.enabled ? "ON" : "OFF")), true);
        }
        bindWasDown = down;
    }

    private static void onStartTick(MinecraftClient mc) {
        checkBind(mc);
        if (menuKey.wasPressed()) {
            if (mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new KurGui());
            }
        } else {
            MaceElytraTarget.tick(mc);
        }
    }
}
